library(testthat)
library(RLumCarlo)

test_check("RLumCarlo")
