#' \tabular{ll}{ Package: \tab RLumCarlo\cr Type: \tab Package\cr Version:
#' \tab 0.0.1\cr Date: \tab 2017-01-31 \cr License: \tab GPL-3\cr }
#'
#' @name RLumCarlo-package
#' @docType package
#' @author \bold{Authors}
#'
#' @import Rcpp
#' @importFrom grDevices adjustcolor
#' @import abind
#' @import foreach
#' @import parallel
#' @import doParallel
#' @import methods
#' @importFrom graphics lines
#' @importFrom graphics plot
#' @importFrom graphics polygon
#' @useDynLib RLumCarlo
NULL
